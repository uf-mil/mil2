from setuptools import setup

package_name = 'SubEnv'

setup(
    name=package_name,
    version='0.0.1',
    packages=['subenv'],
    install_requires=['setuptools'],
    zip_safe=True,
    author='You',
    author_email='you@example.com',
    description='RL environment nodes for Subjugator',
    license='Apache-2.0',
    entry_points={
        'console_scripts': [
            'sub_env      = subenv.sub_env:main',
            'gym_node     = subenv.GymNode:main',
            'locks        = subenv.locks:main',
            'sub_RL_train = subenv.sub_RL_train:main',
        ],
    },
)
