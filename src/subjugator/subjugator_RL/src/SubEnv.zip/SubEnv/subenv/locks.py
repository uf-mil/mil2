import threading

imu_lock = threading.Lock()
cam_lock = threading.Lock()